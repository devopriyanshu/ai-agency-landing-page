import Hero from '@/components/sections/Hero';
import About from '@/components/sections/About';
import Services from '@/components/sections/Services';
import TechStack from '@/components/sections/TechStack';
import Process from '@/components/sections/Process';
import UseCases from '@/components/sections/UseCases';
import Contact from '@/components/sections/Contact';
import { generateSEO } from '@/lib/seo';

export const metadata = generateSEO({
  title: 'Home',
  description: 'Custom AI Agent Engineering - From Simple Automations to Complex Multi-Agent Systems. Build intelligent AI agents using LangChain, RAG, and cutting-edge AI technologies.',
});

export default function HomePage() {
  return (
    <>
      <Hero />
      <About />
      <Services />
      <TechStack />
      <Process />
      <UseCases />
      <Contact />
    </>
  );
}
