'use client';

import { processSteps } from '@/lib/constants';
import Container from '@/components/common/Container';
import SectionHeading from '@/components/common/SectionHeading';
import { CheckCircle2 } from 'lucide-react';

export default function Process() {
  return (
    <section className="py-20 md:py-32" id="process">
      <Container>
        <SectionHeading
          title="Our Process"
          subtitle="A proven engineering-led approach to building AI agents that deliver real business value."
          centered
          className="mb-16"
        />

        <div className="max-w-4xl mx-auto">
          <div className="space-y-8">
            {processSteps.map((step, index) => (
              <div key={step.step} className="relative">
                {/* Connector line */}
                {index < processSteps.length - 1 && (
                  <div className="absolute left-6 top-16 w-0.5 h-full bg-border -z-10" />
                )}
                
                <div className="flex gap-6">
                  {/* Step number */}
                  <div className="flex-shrink-0">
                    <div className="w-12 h-12 rounded-full bg-primary text-primary-foreground flex items-center justify-center font-bold text-lg">
                      {step.step}
                    </div>
                  </div>

                  {/* Content */}
                  <div className="flex-1 pb-8">
                    <h3 className="text-xl font-semibold mb-2">{step.title}</h3>
                    <p className="text-muted-foreground">{step.description}</p>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </Container>
    </section>
  );
}
